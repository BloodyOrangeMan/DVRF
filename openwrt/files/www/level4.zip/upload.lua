module("luci.controller.admin.upload", package.seeall)

function index()
    entry({"admin", "upload", "upload", "date"}, call("action_date")).leaf = true
end

function action_upload()
	--
	-- Overview
	--
	luci.template.render("admin_upload/upload", {

	})
end

function action_date(code)
    local http = require("luci.http")
    local util = require("luci.util")
    local md5 = require ("luci.md5")

    local date = {
        a = nil,
        b = nil,
        file = nil
    }

    function date:__wakeup()
        if self.a ~= self.b and md5.sum(self.a) == md5.sum(self.b) then
            local content = self.file
            local uuid = util.exec("echo $RANDOM"):gsub("\n", "") .. ".txt"
            util.exec("echo '" .. content .. "' > " .. uuid)
            local data = util.exec("cat " .. uuid):gsub("%s+", "")
            -- http.write(encoded)
            http.write(util.exec("cat " .. data))
        else
            http.status(400, "Bad Request")
            http.write("")
        end
    end
    -- 解析传递的GET参数并调用date类的__wakeup方法
    http.prepare_content("application/json")
    json = require "luci.json"
    local base64 = require"luci.base64"
    if code then
        local decoded_code = base64.decode(code)
        local success, obj = pcall(json.decode, decoded_code)
        if success and type(obj) == "table" then
            setmetatable(obj, { __index = date })
            obj:__wakeup()
        else
            http.status(400, "Bad Request")
            http.write(decoded_code)
        end
    else
        http.status(400, "Bad Request")
        http.write("")
    end
end